# CODEX TASK — STAGES 1–8 UI ASSET INTEGRATION, GITHUB-AWARE VERSION

## Project

Repository: `rodchaves73/Veyra-Aetherfall`  
Target branch: `main`  
Work branch: `codex/stage-1-8-ui-assets-integration`

## Context

The current project is already a React + Vite + TypeScript + Tailwind mobile-first Telegram Mini App.

The repository already has:

- AppShell mobile-first with Topbar and BottomNav.
- Home RPG gacha screen.
- Heroes grid with rarity, power, filters and detail modal.
- Battle MVP 5v5 auto turn-based with action bar, HP, energy and logs.
- Dungeons, Summon, Shop, Wallet and Aether Fountain screens.
- Asset pipeline prepared at `public/assets/game`.
- Asset manifest prepared at `src/lib/assets/gameAssets.ts`.
- Safe local placeholders and fallback image components.
- Supabase client prepared only with publishable key.
- Telegram Mini App hook with fallback dev.

This task must improve and connect the approved Stage 1–8 visual assets to the existing layout.  
Do not rebuild the app from scratch.

---

# Objective

Integrate the approved visual assets from Stages 1–8 into the existing game UI while preserving current app architecture, routing, logic, security boundaries and server-side assumptions.

The implementation must be visual/structural only.

---

# Source Package

Use the uploaded asset package:

```txt
veyra_stage1_to_stage8_github_package.zip
```

The package contains reviewed/approved assets for:

```txt
Stage 1 — UI base
Stage 2 — Home / Summon / Battle base
Stage 3 — Heroes / Collection UI
Stage 4 — Inventory / Equipment UI
Stage 5 — Campaign / Missions / Dungeons UI
Stage 6 — Shop / Rewards / Offers UI
Stage 7 — Battle Arena Clean UI
Stage 8 — Profile / Wallet / Settings / Account UI
```

Important:

- This package is not a full app replacement.
- This package is not a source-code patch.
- This package is a visual asset library and implementation guide.
- Stage 10 character assets are intentionally not included as final production assets.

---

# Current Repository Rules to Respect

The repository already defines the official asset pipeline.

Assets should go under:

```txt
public/assets/game/
  backgrounds/
  ui/
  icons/
  frames/
  banners/
  fx/
  heroes/
  enemies/
  items/
  spritesheets/
  placeholders/
```

The asset manifest currently lives at:

```txt
src/lib/assets/gameAssets.ts
```

The implementation should update the existing manifest instead of inventing a second asset system.

Use existing asset components when available:

```txt
GameAssetImage
GameBackground
RarityFrame
AssetSlot
```

Do not bypass fallbacks by hardcoding raw `<img>` paths everywhere if the project already provides a safe asset abstraction.

---

# Absolute Scope Limits

## Do not modify

```txt
- Supabase schema
- Supabase Edge Functions
- Telegram auth validation
- gacha server-side logic
- pity logic
- duplicate conversion
- economy logic
- wallet logic
- TON payments
- Telegram Stars payments
- withdrawals
- marketplace
- NFT logic
- anti-fraud logic
- battle rewards
- inventory server mutations
```

## Do not add

```txt
- service role keys
- private tokens
- wallet private keys
- payment secrets
- external asset URLs as critical runtime assets
- paid/copyrighted third-party assets
- ZIP files committed inside the repo
- PSD/AI/source design files
```

## Do not implement yet

```txt
- final heroes from Stage 10
- character sprites
- hero skill icons
- hero ultimate FX
- real battle animations
- real wallet/withdrawal flow
- paid NFT/marketplace system
```

---

# Required Implementation Approach

## Step 1 — Inspect Current Layout

Before changing files, inspect current code:

```bash
find src -maxdepth 4 -type f | sort
```

Identify actual files for:

```txt
- App shell
- navigation
- topbar
- bottom nav
- home screen
- summon screen
- heroes screen
- battle screen
- campaign/dungeons/missions screens
- inventory/equipment screen, if present
- shop/rewards/offers screen
- profile/wallet/settings/account screens, if present
- asset components
- asset manifest
```

Do not assume file names.

---

## Step 2 — Extract and Sort Assets Locally

Extract the uploaded package locally outside the repository first.

Do not commit the ZIP itself.

Copy only selected optimized image files into:

```txt
public/assets/game/
```

Recommended mapping:

```txt
Stage 1 UI base
→ public/assets/game/ui/
→ public/assets/game/icons/
→ public/assets/game/frames/

Stage 2 Home/Summon/Battle base
→ public/assets/game/backgrounds/
→ public/assets/game/fx/
→ public/assets/game/banners/
→ public/assets/game/ui/

Stage 3 Heroes/Collection UI
→ public/assets/game/ui/
→ public/assets/game/frames/
→ public/assets/game/icons/

Stage 4 Inventory/Equipment UI
→ public/assets/game/ui/
→ public/assets/game/icons/
→ public/assets/game/items/
→ public/assets/game/frames/

Stage 5 Campaign/Missions/Dungeons UI
→ public/assets/game/backgrounds/
→ public/assets/game/ui/
→ public/assets/game/icons/
→ public/assets/game/fx/

Stage 6 Shop/Rewards/Offers UI
→ public/assets/game/ui/
→ public/assets/game/icons/
→ public/assets/game/banners/
→ public/assets/game/fx/

Stage 7 Battle Arena Clean UI
→ public/assets/game/backgrounds/
→ public/assets/game/ui/
→ public/assets/game/fx/
→ public/assets/game/frames/

Stage 8 Profile/Wallet/Settings/Account UI
→ public/assets/game/ui/
→ public/assets/game/icons/
→ public/assets/game/frames/
```

---

# Asset Naming Rules

Rename copied assets to clean kebab-case names.

Use English naming.

Examples:

```txt
background-home-arcane-portal.webp
background-summon-aether-gate.webp
background-battle-astral-arena.webp

ui-panel-dark-arcane.png
ui-panel-profile-ornate.png
ui-button-gold-primary.png
ui-button-danger-ash.png
ui-divider-gold-runes.png

icon-gold.png
icon-gems.png
icon-stamina.png
icon-ticket-standard.png
icon-wallet.png
icon-settings.png
icon-lock.png

frame-common.png
frame-rare.png
frame-epic.png
frame-legendary.png
frame-divine.png
frame-mythic.png

fx-summon-portal-glow.png
fx-slot-active-glow.png
fx-ui-shimmer.png
```

Do not keep random export names if they are unclear.

Do not create final hero names from Stage 10 yet.

---

# Compression / Performance

Optimize before committing.

Rules:

```txt
- Use WebP for large backgrounds, banners and splash-like non-transparent images.
- Use PNG for transparent UI, icons, frames and FX.
- Avoid giant files.
- Validate mobile use at 360px, 390px and 430px portrait widths.
- Do not commit full-resolution source sheets when smaller runtime assets are sufficient.
```

Target limits when possible:

```txt
Background: under ~300 KB
Banner: under ~200 KB
Icon: under ~50 KB
Frame/UI piece: under ~100 KB
FX: under ~150 KB unless necessary
```

If not possible without visible quality loss, document the exception in the PR.

---

# Update Asset Manifest

Update:

```txt
src/lib/assets/gameAssets.ts
```

Preserve:

```txt
- existing `asset(...)` helper
- existing fallbackSrc strategy
- existing categories
- existing placeholders
```

Add or map new assets under the existing categories.

If TypeScript types require changes, update:

```txt
src/lib/assets/gameAssets.types.ts
```

Do not create a parallel manifest.

Do not remove existing placeholders.

---

# Screen Integration Requirements

## Home

Use Stage 1–2 assets to improve:

```txt
- background
- primary panels
- buttons
- top resource visuals
- portal/central call-to-action area
- daily/reward/quest visual blocks
```

Preserve current Home functionality.

---

## Summon

Use Stage 2 assets to improve:

```txt
- summon portal/gate
- summon circle
- banner panels
- ticket/currency icons
- summon buttons
- reveal/reward frames
```

Do not change real gacha logic.

If current summon is mock/visual, keep it mock unless server-side logic already exists.

---

## Heroes / Collection

Use Stage 3 assets to improve:

```txt
- hero grid cards
- rarity frames
- detail modal/panel
- filter tabs
- upgrade/shard visual bars
- empty slots/placeholders
```

Important:

```txt
Stage 10 final heroes are paused.
Use placeholders or current hero data only.
Do not add final generated character art yet.
```

---

## Inventory / Equipment

Use Stage 4 assets to improve:

```txt
- inventory item grid
- item cards
- equipment slots
- item detail panel
- rarity glow
- filter tabs
- resource icons
```

Do not create real economy mutations.

---

## Campaign / Missions / Dungeons

Use Stage 5 assets to improve:

```txt
- campaign map visual
- dungeon cards
- stage nodes
- reward slots
- mission cards
- progress visuals
- difficulty badges
```

Do not change reward authorization or server-side assumptions.

---

## Shop / Rewards / Offers

Use Stage 6 assets to improve:

```txt
- shop cards
- reward panels
- login reward frames
- claim buttons
- offer cards
- price tag frames
- free/ad visual button frames
```

Do not implement real purchases, TON, Stars, NFT, marketplace or withdrawals.

---

## Battle

Use Stage 7 assets only as structural UI.

Stage 7 rules are strict:

```txt
- no fixed HP/MP/energy fills from asset
- no final hero skill icons
- no final ultimate icons
- no character sprites
- no final ability FX
```

Use the assets for:

```txt
- arena background
- ally/enemy position slots
- target markers
- top HUD frame
- boss HUD frame
- empty HP/MP/energy bar frames only
- turn order frame
- portrait card frames
- selected hero card frame
- empty skill wheel
- empty skill slots
- empty ultimate slot
- command buttons
- generic UI highlights
```

The actual HP, MP, energy, cooldowns, values and skill icons must remain rendered by code or placeholder UI.

---

## Profile / Wallet / Settings / Account

Use Stage 8 assets to improve:

```txt
- profile panel
- avatar frame
- player stats
- achievement badges
- ranking panel
- wallet visual card
- wallet connect visual button
- settings toggles
- selectors
- support/inbox/message cards
- security/lock icons
```

Wallet is visual/structural only unless existing safe wallet logic already exists.

Do not add new real payment or withdrawal behavior.

---

# CSS / Layout Requirements

Preserve the current mobile-first layout.

Do:

```txt
- keep portrait-first design
- keep safe area handling
- avoid horizontal overflow
- use CSS variables where helpful
- use transform/opacity for light animations
- keep animations subtle
- respect prefers-reduced-motion
```

Do not:

```txt
- create desktop-first layouts
- introduce Canvas/Phaser
- add heavy animation libraries
- break Telegram Mini App viewport behavior
- rewrite all screens if only visual asset replacement is needed
```

---

# Character Pipeline Pause Note

Characters are paused.

Do not integrate generated character experiments from Stage 10.

Approved Stage 10 character rules for future reference only:

```txt
- use Character Bible before every hero
- English naming only
- Aetherborn replaces Meio-Aether
- Aether element only Divine/Mythic
- one class per hero
- one element per hero
- splash/front/back must have exact same outfit, weapon, palette and silhouette
- in-game front and back must be separate images
- images must be generated for clean recut and future sprites
```

Do not implement these characters now.

---

# Required Documentation Updates

Create or update:

```txt
docs/STAGE_1_8_ASSET_INTEGRATION.md
docs/ASSET_STAGE_STATUS.md
docs/CHARACTER_PIPELINE_PAUSE_NOTE.md
```

`docs/STAGE_1_8_ASSET_INTEGRATION.md` should explain:

```txt
- what assets were added
- where they were placed
- which screens use them
- any intentionally skipped assets
- any compression/performance notes
```

`docs/ASSET_STAGE_STATUS.md` should mark:

```txt
Stage 1 — approved / integrated or partially integrated
Stage 2 — approved / integrated or partially integrated
Stage 3 — approved / integrated or partially integrated
Stage 4 — approved / integrated or partially integrated
Stage 5 — approved / integrated or partially integrated
Stage 6 — approved / integrated or partially integrated
Stage 7 — approved / integrated or partially integrated
Stage 8 — approved / integrated or partially integrated
Stage 9 — documentation merged
Stage 10 — paused
```

`docs/CHARACTER_PIPELINE_PAUSE_NOTE.md` should summarize that characters are intentionally excluded.

---

# Validation

Run:

```bash
npm install
npm run lint
npm run build
npm run typecheck
git diff --check
test -f dist/index.html
```

Run secret scan:

```bash
rg -n "SUPABASE_SERVICE_ROLE_KEY|service[_-]?role|TELEGRAM_BOT_TOKEN|DATABASE_URL|postgres(ql)?://|password=|TON private key|admin secret|payment secret" . || true
```

If the secret scan returns existing documentation references, report them clearly and confirm none were added by this task.

---

# Required Final Report

Return a final report with:

```txt
Initial SHA:
Branch:
Commit:
Files added:
Files modified:
Number of image assets added:
Total size added:
Screens touched:
Assets integrated by stage:
Skipped assets and why:
Lint:
Build:
Typecheck:
git diff --check:
dist/index.html:
Secret scan:
Risks:
PR:
Merge:
```

Do not merge the PR.

---

# PR

Open a small focused PR.

Title:

```txt
Stage 1–8 — Integrate approved UI assets
```

Description:

```md
## Summary

Integrates approved Veyra Stage 1–8 UI assets into the existing mobile-first React/Vite layout.

## Scope

- Adds optimized local game assets under `public/assets/game`
- Updates existing asset manifest and fallbacks
- Applies visual assets to existing screens where appropriate
- Documents stage integration status
- Keeps Stage 10 characters paused

## Not included

- No final hero/sprite integration
- No gacha logic changes
- No Supabase changes
- No economy changes
- No wallet/payment/TON/Stars/NFT/marketplace changes
- No battle rewards changes

## Validation

- npm run lint
- npm run build
- npm run typecheck
- git diff --check
- dist/index.html exists
- secret scan
```

Do not merge.
