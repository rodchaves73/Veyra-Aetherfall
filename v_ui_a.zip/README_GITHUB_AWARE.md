# Veyra Stage 1–8 GitHub-Aware Integration Package

This package is a visual asset package plus a corrected Codex instruction based on the current GitHub project state.

Use this file for Codex:

```txt
CODEX_STAGE1_8_IMPLEMENTATION_GITHUB_AWARE.md
```

Important:

- Do not rebuild the app from scratch.
- Preserve the existing AppShell, Topbar, BottomNav and current screens.
- Copy selected optimized assets into `public/assets/game`.
- Update the existing `src/lib/assets/gameAssets.ts` manifest.
- Do not implement Stage 10 character assets yet.
