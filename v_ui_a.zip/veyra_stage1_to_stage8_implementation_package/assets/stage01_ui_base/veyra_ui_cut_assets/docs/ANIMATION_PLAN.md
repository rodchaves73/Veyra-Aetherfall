# Veyra UI — Plano de Animação dos Assets

Este pacote é uma etapa parcial da interface do Veyra: Aetherfall.

A estética foi aprovada, mas estes arquivos ainda NÃO são o pacote final oficial do projeto.  
A organização e a renomeação definitiva devem acontecer somente depois que todos os assets das telas forem criados.

## Direção geral

A interface deve ter animação seletiva, elegante e leve.

Não animar tudo.  
Animar apenas o que dá vida ao jogo sem prejudicar legibilidade nem performance no Telegram Mini App.

Estilo de animação:

- dark fantasy arcano;
- brilho roxo/violeta suave;
- dourado cintilando de forma discreta;
- partículas mágicas leves;
- pulsos lentos;
- movimento premium, sem exagero;
- nada cômico;
- nada tremendo o tempo inteiro.

## Regras técnicas

Preferência por animação via código/CSS para UI:

- `opacity`
- `transform`
- `filter`
- `box-shadow`
- overlays de brilho
- pseudo-elementos
- partículas leves separadas

Evitar transformar todos os painéis em sprites animados.

Sprites animados devem ser reservados para:

- portal;
- summon circle;
- FX mágico;
- baús;
- orbes;
- cristais;
- personagens;
- inimigos;
- bosses.

## O que NÃO deve ser animado como sprite

Estes grupos devem ser tratados como UI estática com animação via CSS:

- `ui/panels/*`
- `ui/buttons/*`
- `ui/nav/*`
- `ui/frames/*`

Motivo: são elementos de layout. Transformá-los em sprites pode pesar o app e dificultar responsividade.

## O que pode receber animação por CSS

### `ui/buttons/*`

Animação recomendada:

- pulso leve no brilho da borda;
- brilho roxo/dourado no estado ativo;
- micro escala no toque;
- transição curta ao pressionar;
- shimmer diagonal muito sutil em botão principal.

Uso:

- botões de ação da Home;
- botão de Summon;
- botão de Battle;
- botão de Claim/Start.

Não usar loop forte em todos os botões ao mesmo tempo.

### `ui/nav/*`

Animação recomendada:

- item ativo com glow roxo pulsando lentamente;
- ícone ativo subindo 1–2px;
- brilho sutil atrás do botão ativo;
- badge de notificação com pulso pequeno.

Não animar a barra inteira o tempo todo.

### `ui/frames/*`

Animação recomendada por raridade:

- common: sem animação;
- uncommon: brilho quase imperceptível;
- rare: glow azul/ciano leve;
- epic: pulso violeta;
- legendary: shimmer dourado lento;
- divine: brilho branco/dourado suave;
- mythic: aura roxa/cósmica com partículas leves.

A animação deve ser feita por overlay/CSS, não alterando o PNG original.

### `ui/panels/*`

Animação recomendada:

- painel principal pode ter glow interno bem sutil;
- painel de missão pode ter borda com brilho lento;
- cards importantes podem ter shimmer raro;
- painéis comuns devem ficar estáticos.

Não animar todos os painéis simultaneamente.

## Ícones

Os arquivos `icons/icon_01.png` até `icons/icon_35.png` devem ser avaliados depois da renomeação final.

Como regra geral:

### Ícones que devem ficar estáticos

- configurações;
- inventário;
- ranking;
- escudo;
- espada comum;
- menus;
- navegação comum.

### Ícones que podem ter animação CSS leve

- moeda/ouro: brilho dourado ocasional;
- gema/cristal: pulso violeta/ciano;
- energia/stamina: pulso curto;
- ticket de summon: brilho mágico;
- estrela: cintilação;
- baú: brilho externo;
- magia elemental: glow leve.

### Ícones que podem virar sprites no futuro

Somente se forem usados como foco visual:

- ícone de summon;
- baú de recompensa;
- cristal/gema premium;
- orbe de Aether;
- estrela de raridade;
- magia/skill principal.

## Telas que devem ter animação

### Home

Prioridade alta.

Animar:

- portal central;
- partículas mágicas;
- névoa baixa;
- cristais;
- botão principal;
- nav ativo;
- painel de missão com brilho sutil.

Não animar:

- todos os cards;
- todos os ícones;
- todos os textos;
- todos os painéis.

### Summon / Gacha

Prioridade máxima.

Animar:

- círculo mágico;
- runas girando;
- portal de invocação;
- partículas;
- brilho de ticket/gema;
- revelação de raridade;
- flash de card;
- estrela/raridade aparecendo.

Esta tela pode receber sprites e FX dedicados.

### Heroes

Prioridade média.

Animar:

- aura do herói;
- frame de raridade;
- partículas raras;
- arma brilhando;
- idle do personagem quando os heróis forem criados.

UI de lista deve ficar majoritariamente estática.

### Battle

Prioridade alta, mas em etapa posterior.

Animar:

- personagens;
- inimigos;
- skills;
- impacto;
- dano;
- vitória;
- morte/queda.

A UI da battle deve ser leve; os sprites devem concentrar a ação.

### Shop / Inventory / Quests

Prioridade baixa.

Animar apenas:

- destaque de oferta;
- baú/recompensa;
- badge;
- botão de claim;
- item raro com brilho.

## Ordem recomendada de produção

1. Criar todos os assets estáticos por tela.
2. Recortar/remover fundo.
3. Enviar para revisão.
4. Só depois organizar e renomear tudo oficialmente.
5. Selecionar assets que merecem animação.
6. Criar sprites/FX apenas dos elementos prioritários.
7. Integrar no projeto com CSS leve e lazy loading.

## Decisão atual

Este pacote atual deve ser tratado como:

- UI Stage 1 aprovada visualmente;
- recorte aprovado;
- ainda sem nomes finais;
- ainda sem integração;
- ainda sem animações definitivas.

Próxima etapa recomendada:

Criar os assets da tela Home:
- background;
- portal;
- cristais;
- colunas;
- chão;
- névoa;
- partículas;
- props mágicos;
- elementos de cenário em camadas.
