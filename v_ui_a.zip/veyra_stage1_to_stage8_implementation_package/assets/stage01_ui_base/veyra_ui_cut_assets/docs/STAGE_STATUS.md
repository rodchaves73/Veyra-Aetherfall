# Veyra UI Cut Assets — Stage 1

Este ZIP contém os primeiros assets recortados da interface do Veyra: Aetherfall.

## Status

Aprovado como base visual da interface, mas ainda não é o pacote final.

## Conteúdo

- `ui/panels/`
- `ui/buttons/`
- `ui/nav/`
- `ui/frames/`
- `icons/`
- `preview/`
- `manifest/`
- `docs/ANIMATION_PLAN.md`

## Observação importante

A renomeação final deve ser feita somente depois que todos os assets das telas forem criados.

Motivo: vários arquivos ainda têm nomes genéricos como `panel_01.png`, `icon_01.png`, `button_01.png`.  
Renomear agora pode gerar retrabalho quando chegarem os assets das próximas telas.
