# CODEX TASK — Implement Veyra: Aetherfall UI Assets Stages 1–8

## Objective

Integrate the approved visual UI assets from Stages 1–8 into the existing Veyra: Aetherfall project.

This task is a visual/game-shell implementation pass only. Do not implement final heroes, final sprites, real skills, real battle balancing, real wallet/payment flow, NFT, marketplace, or economic authority changes.

## Required source folder

Use the package folder:

```txt
assets/
```

Each stage is separated:

```txt
assets/stage01_ui_base
assets/stage02_home_summon_battle_ui_expanded
assets/stage03_heroes_collection_ui
assets/stage04_inventory_equipment_ui
assets/stage05_campaign_missions_dungeons_ui
assets/stage06_shop_rewards_offers_ui
assets/stage07_battle_layout_final_ui
assets/stage08_profile_wallet_settings_ui
```

## Implementation goals

1. Move or copy approved assets into the app public/src asset structure using clean, stable paths.
2. Create a typed asset registry/map so screens do not hardcode random filenames.
3. Apply assets to these visual areas:
   - Home
   - Summon
   - Battle shell
   - Heroes / Collection
   - Inventory / Equipment
   - Campaign / Missions / Dungeons
   - Shop / Rewards / Offers
   - Profile / Wallet / Settings / Account
4. Preserve current Telegram Mini App compatibility and mobile portrait layout.
5. Keep frontend strictly visual for restricted systems.

## Important restrictions

### Security and economy

Do not add service role keys to the frontend.
Do not create client-side authority over currency, rewards, gacha, pity, battle rewards, payments, withdrawals, marketplace, or NFT.
Do not expose secrets.
Do not change Supabase security behavior unless explicitly required by existing safe patterns.

### Stage 7 Battle UI restrictions

Battle layout is structural only.
Do not implement fixed HP/MP/energy bars if they cannot be data-bound later.
Do not create final skill icons.
Do not create ultimate icons.
Do not create character-specific battle FX.
Do not create final hero sprites.
Use placeholders and clean slots only.

Battle should support later configuration for:
- ally slots
- enemy slots
- selected hero card slot
- empty skill slots
- empty ultimate slot
- boss/top HUD shell
- commands like auto/speed/pause as UI shell only

### Stage 8 Wallet/Profile restrictions

Profile, wallet, settings and account screens are visual shell only unless a safe existing integration already exists.
No real TON payment, withdrawal, marketplace, NFT, or purchase logic should be introduced in this task.

### Stage 10 character restriction

Do not integrate unfinished Stage 10 character assets as final game assets.
Use placeholders for heroes until final character pipeline is complete.

## Suggested implementation structure

Create or update something similar to:

```txt
src/assets/veyraAssetRegistry.ts
src/components/game/GameAssetImage.tsx
src/components/game/GameBackground.tsx
src/screens/HomeScreen.tsx
src/screens/SummonScreen.tsx
src/screens/BattleScreen.tsx
src/screens/HeroesScreen.tsx
src/screens/InventoryScreen.tsx
src/screens/CampaignScreen.tsx
src/screens/ShopScreen.tsx
src/screens/ProfileScreen.tsx
src/screens/SettingsScreen.tsx
```

Use existing project conventions if these files already exist.

## Styling rules

- Maintain dark arcane fantasy identity.
- Purple / violet / deep blue / black / aged gold.
- Mobile-first portrait UI.
- No generic app UI.
- No sci-fi/cyberpunk style.
- Text/data should be rendered by the app, not baked into fixed assets when possible.
- Use CSS animation only for subtle shimmer, glow, selected states, button press, and rarity frame pulse.

## Testing required

Run and report:

```bash
npm install
npm run lint
npm run build
npm run typecheck
npm run test -- --run || true
```

If a command does not exist, report that clearly and continue with available checks.

Also run:

```bash
git diff --check
test -f dist/index.html
```

## Final report required

Return:

- Initial SHA
- Branch name
- Commit SHA
- Files created/changed
- Asset folders copied/mapped
- Screens updated
- Tests/lint/build/typecheck results
- Confirmation no secrets added
- Confirmation no real payments/wallet/marketplace/NFT added
- Confirmation Stage 10 characters were not finalized/integrated
- PR link if created
- Whether merge was done or not

## Commit title suggestion

```txt
Stage 1-8 UI asset integration
```
