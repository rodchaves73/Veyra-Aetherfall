# Character Pipeline Pause Note

Stage 10 character production is paused and must not be treated as final implementation input.

Validated character rules for later:

- Always follow the Character Bible before creating a hero.
- English nomenclature only: Faction, Race, Class, Element, Rarity, Role.
- Aetherborn replaces the old Meio-Aether name.
- Element Aether is restricted to Divine and Mythic heroes only.
- One hero = one class and one element.
- Splash art, in-game front and in-game back must share the exact same outfit, weapon, palette, symbols and silhouette.
- No mixed weapons between splash and in-game assets.
- No mixed costumes between splash and in-game assets.
- Front/back assets must be separate images, clean for cutout and future sprite generation.
- Common rarity must be simple; visual detail increases by rarity.

Do not integrate unfinished character experiments as final playable hero assets.
