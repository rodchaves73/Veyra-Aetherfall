# Implementation Notes

This package is meant to move the project forward while the character pipeline is paused.

Recommended strategy:

1. Integrate UI assets first.
2. Use placeholders for heroes/enemies/skills.
3. Keep all restricted game authority server-side.
4. Keep visual screens configurable and data-driven.
5. Do not encode permanent gameplay numbers into the artwork.

Battle UI note:
Do not use fixed HP/MP/energy artwork as final logic. Any bars/slots must be configurable React components that can receive values later.

Shop/Wallet note:
These screens should not imply a real purchase/withdrawal flow unless it already exists safely in the project.
