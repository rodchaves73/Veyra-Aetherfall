# Stage Status — Veyra UI Assets

## stage01_ui_base
- Source: `veyra_ui_stage1_with_animation_plan.zip`
- Description: UI Base: panels, buttons, frames, icons, nav and base animation plan.
- PNG count: 61
- Top categories:
  - `icons`: 35
  - `ui/nav`: 8
  - `ui/buttons`: 6
  - `ui/panels`: 5
  - `ui/frames`: 5
  - `preview`: 2

## stage02_home_summon_battle_ui_expanded
- Source: `veyra_assets_stage2_cut.zip`
- Description: Home, summon, battle early UI, portal, FX, icons and expanded visual set.
- PNG count: 275
- Top categories:
  - `icons`: 73
  - `summon/fx`: 39
  - `ui/frames`: 34
  - `ui/nav`: 29
  - `battle/ui`: 17
  - `battle/fx`: 15
  - `home/props`: 15
  - `ui/panels`: 8
  - `ui/buttons`: 8
  - `summon/cards`: 8

## stage03_heroes_collection_ui
- Source: `veyra_heroes_ui_clean_cut_reviewed.zip`
- Description: Heroes and collection UI assets only, no final characters.
- PNG count: 171
- Top categories:
  - `heroes/portrait_slots`: 32
  - `heroes/badges`: 18
  - `heroes/rarity_frames`: 18
  - `heroes/cards`: 15
  - `heroes/fx`: 15
  - `heroes/filters`: 10
  - `heroes/decorative`: 8
  - `heroes/equipment_slots`: 6
  - `heroes/buttons`: 6
  - `heroes/highlights`: 6

## stage04_inventory_equipment_ui
- Source: `veyra_inventory_equipment_ui_cut_reviewed.zip`
- Description: Inventory and equipment UI assets.
- PNG count: 174
- Top categories:
  - `inventory/item_cards`: 41
  - `inventory/equipment_slots`: 18
  - `ui/icons`: 14
  - `inventory/decorative`: 13
  - `inventory/category_tabs`: 11
  - `inventory/item_icon_frames`: 8
  - `inventory/element_filters`: 8
  - `ui/buttons`: 8
  - `inventory/item_detail_panel`: 7
  - `inventory/resource_icons`: 7

## stage05_campaign_missions_dungeons_ui
- Source: `veyra_campaign_missions_dungeons_ui_cut_reviewed.zip`
- Description: Campaign, missions and dungeon UI assets.
- PNG count: 142
- Top categories:
  - `campaign/stage_status_icons`: 20
  - `campaign/reward_slots`: 20
  - `campaign/route_markers`: 16
  - `campaign/progress_bars`: 11
  - `campaign/decorative`: 8
  - `campaign/chapter_panels`: 7
  - `campaign/star_completion`: 7
  - `ui/icons`: 7
  - `campaign/energy_badges`: 5
  - `campaign/chest_rewards`: 5

## stage06_shop_rewards_offers_ui
- Source: `veyra_shop_rewards_offers_ui_cut_reviewed.zip`
- Description: Shop, rewards and offers UI assets. Visual only.
- PNG count: 129
- Top categories:
  - `shop/decorative`: 20
  - `ui/icons`: 11
  - `shop/reward_slots`: 10
  - `shop/login_rewards`: 9
  - `shop/daily_rewards`: 7
  - `shop/pack_cards`: 6
  - `shop/category_tabs`: 6
  - `shop/resource_icons`: 6
  - `ui/buttons`: 6
  - `shop/offer_cards`: 5

## stage07_battle_layout_final_ui
- Source: `veyra_battle_arena_clean_ui_cut_reviewed.zip`
- Description: Battle arena final clean structural UI. No fixed HP/MP/energy, no skills, no characters.
- PNG count: 147
- Top categories:
  - `battle/wave_indicators`: 11
  - `battle/generic_fx`: 11
  - `battle/action_point_frames`: 10
  - `battle/turn_order`: 9
  - `battle/dividers`: 8
  - `battle/elemental_icon_frames`: 6
  - `battle/class_icon_frames`: 6
  - `battle/ally_slots`: 5
  - `battle/enemy_slots`: 5
  - `battle/portrait_cards`: 5

## stage08_profile_wallet_settings_ui
- Source: `veyra_profile_wallet_settings_ui_cut_reviewed.zip`
- Description: Profile, wallet, settings and account UI. Visual only; no real payments/withdrawals.
- PNG count: 141
- Top categories:
  - `decorations/generic_fx`: 14
  - `settings/option_buttons`: 13
  - `profile/stats_panels`: 12
  - `settings/selectors`: 12
  - `settings/toggles`: 8
  - `profile/achievement_badges`: 7
  - `wallet/wallet_icons`: 7
  - `decorations/emblems`: 7
  - `settings/language_icons`: 6
  - `ui_common/icons`: 6
