# Veyra: Aetherfall — Stage 1–8 Implementation Package

Pacote organizado para subir no GitHub e usar como base de implementação visual no projeto.

## Escopo incluído

- Stage 1 — UI Base
- Stage 2 — Home / Summon / Battle / UI Expanded
- Stage 3 — Heroes / Collection UI
- Stage 4 — Inventory / Equipment UI
- Stage 5 — Campaign / Missions / Dungeons UI
- Stage 6 — Shop / Rewards / Offers UI
- Stage 7 — Battle Layout Final UI
- Stage 8 — Profile / Wallet / Settings / Account UI

## Escopo NÃO incluído

- Stage 10 Characters / Heroes finais
- sprites finais
- skills e ultimates reais
- balanceamento de combate
- economia real
- wallet real
- pagamentos reais
- marketplace / NFT
- Supabase schema novo
- alteração de secrets

## Como usar

1. Suba este pacote no GitHub ou extraia os assets dentro do repositório.
2. Entregue o arquivo `CODEX_STAGE1_8_IMPLEMENTATION.md` para o Codex.
3. O Codex deve integrar os assets visualmente, mantendo a lógica server-side já existente.
4. Personagens finais devem continuar como placeholders até a Stage 10 ser concluída.

## Estrutura

- `assets/` — assets organizados por stage.
- `source_zips/` — zips originais/reviewed usados como fonte.
- `previews/` — folhas de revisão quando disponíveis.
- `docs/` — regras de implementação e status.
- `manifest.json` — resumo técnico do pacote.
